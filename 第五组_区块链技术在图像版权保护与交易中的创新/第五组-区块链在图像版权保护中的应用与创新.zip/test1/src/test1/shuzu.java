package test1;

import java.io.File;
import java.util.Arrays;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

public class shuzu {
    int size=256;	     
    double[][] arr = new double[15][size];
    String[][] ss=new String[15][size];
    String[] aa =new String[15];
    public shuzu() 
    {
        getData(ss,arr);//这里是从excel中提取数据存到了一个string数组里
	String allStr4="";
	for(int e=0;e<15;e++){
            StringBuffer sb1 = new StringBuffer();
            allStr4=sb1.append(Arrays.toString(ss[e])).toString();
            aa[e]=allStr4;
	}			
	System.out.println();					
	System.out.println(Arrays.toString(ss[0]));
	System.out.println(aa[2]);		
    }
    
    public static void getData(String x[][],double y[][])
    {
    	  
  		try {
  		Workbook workbook=Workbook.getWorkbook(new File("/Users/re./Desktop/Blockchain/feature_result.xls"));
  		Sheet sheet=workbook.getSheet(0);
  		int a=0;
		int b=0;
			for (int i = 0; i < sheet.getRows(); i++) {
				a++;
				for (int j = 0; j < sheet.getColumns(); j++) 
				{
			
					Cell cell=sheet.getCell(j, i);
					x[i][j]=(cell.getContents());
					if(j>1)
					 {y[i][j]=Double.parseDouble(cell.getContents());}
					System.out.print(cell.getContents()+" "); 
					b=j+1;
				}
				System.out.println();   
			}
			System.out.println(Arrays.toString(x[3]));  
    }

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
