package test1;

import java.security.Security;
import java.util.ArrayList;
import java.util.HashMap;
import javax.crypto.Cipher;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashMap;
import java.util.Map;
import com.google.gson.GsonBuilder;

import test1.Block;
public class NoobChain {
	public static ArrayList<Block> blockchain = new ArrayList<Block>();
	public static int difficulty = 5;

	public static void main(String[] args) {

        shuzu a = new shuzu();

        int count = 1;
        int max_size = 5;//写几出几个链
        boolean flag = false;//用于判断是否相似度过高的一个flag
        blockchain.add(new Block(a.aa[0], "0"));

        while(count <= max_size&&!flag){
            IMED b;
            System.out.println("Trying to Mine block"+ count +"... ");
            blockchain.get(count-1).mineBlock(difficulty);
            if(count < max_size){
                b = new IMED(a.arr,count+1);
                b.CalculateEuclideanDistance();
                if(b.GetisX()){
                    System.out.println("相似度过高，拒绝上链哦亲");
                    flag = true;
                }
                else
                    blockchain.add(new Block(a.aa[count],blockchain.get(blockchain.size()-1).hash));
            }
            count++;
        }

        System.out.println("\nBlockchain is Valid: " + isChainValid());
        String blockchainJson = new GsonBuilder().setPrettyPrinting().create().toJson(blockchain);
        System.out.println("\nThe block chain: ");
        System.out.println(blockchainJson);
    }

public static Boolean isChainValid() {
	Block currentBlock;
	Block previousBlock;
	String hashTarget = new String(new char[difficulty]).replace('\0', '0');
	for(int i=1; i < blockchain.size(); i++) {
		currentBlock = blockchain.get(i);
		previousBlock = blockchain.get(i-1);
		if(!currentBlock.hash.equals(currentBlock.calculateHash()) ){
			System.out.println("Current Hashes not equal");
		return false;
		}
	if(!previousBlock.hash.equals(currentBlock.previousHash) ) {
		System.out.println("Previous Hashes not equal");
		return false;
		}
	//增加hash值是否已经计算过
	if(!currentBlock.hash.substring( 0, difficulty).equals(hashTarget)) {
		System.out.println("This block hasn't been mined");
		return false;
		}
	}
return true;
}
}