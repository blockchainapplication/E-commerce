package test1;

import java.util.Date;

import test1.StringUtil;

public class Block {
	public String hash;
	public String previousHash; 
	private long timeStamp; 
	private int nonce;
	private String Data;
	int size=256; // 定义数组


	
	public Block(String Data,String previousHash ) {
		this.previousHash = previousHash;
		this.timeStamp = new Date().getTime();
		this.Data = calculatedDataHash(Data);
		this.hash = calculateHash(); //Making sure we do this after we set the other values.

	}

	public String calculateHash() {
		String calculatedhash = StringUtil.applySha256( 
				previousHash +
				Long.toString(timeStamp) +
				Integer.toString(nonce) +
				Data
				);
		return calculatedhash;
	}
	
	public String calculatedDataHash(String Data) {
		String calculatedDataHash = StringUtil.applySha256(
				Data);
		return calculatedDataHash;
	}

	
	public void mineBlock(int difficulty) {
		String target = new String(new char[difficulty]).replace('\0', '0');
		while(!hash.substring( 0, difficulty).equals(target)) {
		nonce ++;
		hash = calculateHash();
		}
		System.out.println("Block Mined!!! : " + hash);

	}
}
