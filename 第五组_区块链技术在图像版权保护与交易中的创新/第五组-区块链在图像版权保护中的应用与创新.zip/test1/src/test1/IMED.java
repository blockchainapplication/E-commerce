package test1;


import java.io.File;
import java.util.Arrays;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

public class IMED {
	static int size=256;
    static double x = 0.175;//边界值
    double[][] arr;
    double[] distance;
    int currentSize;//当前区块链链数
    boolean isX = false;//判断是否达到临界值用的flag，当欧式距离超过x时，将isX设置为true
    
    public IMED(double[][] arr,int currentSize){
        this.arr = arr;
        this.currentSize = currentSize;
        this.distance = new double[currentSize - 1];//因为若区块链有n个数据上链，则要计算n-1次distance
    }    
    public void CalculateEuclideanDistance(){
        try {          
            for (int i = 0; i < currentSize - 1; i++)//只要计算n-1次distance
            {
                for(int j=0;j<size;j++)	
                {
                    distance[i] += Math.pow((arr[currentSize - 1][j] - arr[i][j]), 2);
                }
            }
            for(int i=0;i<distance.length;i++)				
            {
                distance[i] = Math.sqrt(distance[i]);
                if(distance[i] < x)
                {
                    isX = true;
                }
            }			
        }
	catch (Exception e) {
            e.printStackTrace();
	}
    }
    public boolean GetisX(){
        return isX;
    }
}
