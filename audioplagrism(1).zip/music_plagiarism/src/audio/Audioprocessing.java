package audio;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Audioprocessing {
	   /**
	    * ��ȡ��Ƶ����
	    *
	    * @param filePath ��Ƶ�����ļ�·��
	    * @return
	    */
	   public static short[] getAudioData(String filePath) {
	       File file = new File(filePath);
	       System.out.println("File info   " + file.length());
	       DataInputStream dis = null;
	       short[] audioData = null;
	       try {
	          dis = new DataInputStream(new BufferedInputStream(new FileInputStream(file)));
	    	 //  dis = new DataInputStream(new FileInputStream(file));
	           // file.length() / 2 +1 : /2 : ��λbyte���ݱ���Ϊһλshort����; +1 : �����ļ���β��־
	           audioData = AudioDataOperate.getAudioData(dis, (int) file.length()/512);
	           dis.close();
	       } catch (FileNotFoundException e) {
	           e.printStackTrace();
	       } catch (IOException e) {
	           e.printStackTrace();
	       }
	       return audioData;
	   }
	   
	   
	   /**
	    * ��ʾԭʼ���Σ�������һ��������
	    *
	    * 
	    */
	   public static double[] showAudioWave(String standardAudioFilePath) {
		   double[] standardAudioData;
		   System.out.println("showAudioWave");
		   short[] data = getAudioData(standardAudioFilePath);
		
		   standardAudioData = AudioDataOperate.normalize(data);
		   return standardAudioData;
	   }
	   
	   /**
	    * ��ʾ�˲�����
	    *
	    * 
	    */
	   static double[] showFilterWave(double[] standardAudioData) {
		   if (null == standardAudioData) {
	           return standardAudioData;
	       }
	       // y(n) = 1*x(n)+(-0.9375)*x(n-1)  �˲�
	       standardAudioData = AudioDataOperate.filter(standardAudioData, 1, -0.9375);
	       standardAudioData = AudioDataOperate.normalize(standardAudioData);
	       // standardAudioData = AudioDataOperate.getUsefulData(standardAudioData);
	       return standardAudioData;
	   }
	   
	   
	   /**
	    * ��ʾ��ʱ��������
	    *
	    * 
	    */
	   static double[] showEnergyWave(double[] standardAudioData) {
		   double[] standardEnergyData;
		   if (null == standardAudioData) {
			   return standardAudioData;
	       }
	       double[] dotProductData = AudioDataOperate.dotProduct(standardAudioData);
	       double[] wins = AudioDataOperate.generateHammingWindows(32, 16);
	       double[] convValue = AudioDataOperate.conv(dotProductData, wins);
	       standardEnergyData = AudioDataOperate.normalize(convValue);
	     //  drawWave(mStandardAudioWaveView, standardEnergyData);
	       return standardEnergyData;
	   }
	   
	   /**
	    * ��ʾ��ȡ��Ч��ʱ�������ݲ���
	    *
	    * 
	    */
	   static double[] showUsefulWave(double[] standardEnergyData) {
		   double[] standardUsefulData;
		   if (null == standardEnergyData) {
	           return standardEnergyData;
	       }
	       standardUsefulData = AudioDataOperate.getUsefulData(standardEnergyData);
	       return standardUsefulData;
	   }
	   
	   /**
	    * ����ԱȽ��
	    */
	    static double calculateCompareResult(double[] standardUsefulData,double[] compareUsefulData) {
	    	double similarity;
	        if (null == standardUsefulData || null == compareUsefulData) {
	        	System.out.println("standardUsefulData or compareUsefulData is null");
	            return 0;
	        }
	        final double result = AudioDataOperate.cosineDistance(standardUsefulData, compareUsefulData);
	        System.out.println((int) (result * 100) + "%");

	        return result;

	    }
	    public static double[] music_data_get(String standardAudioFilePath) {
	 	   double[] standardAudioData;
	 	   double[] standardAudioData1;
	 	   double[] standardEnergyData;
	 	   double[] standardUsefulData;
//	 	   1. ��Ƶ�˲�
	 	   standardAudioData = showAudioWave(standardAudioFilePath);
	 	   standardAudioData1 = showFilterWave(standardAudioData);
	        System.out.println("��ʾԭʼ���Σ�������һ��������");
//	       2.������Ƶ�źŶ�ʱ����
	        standardEnergyData =showEnergyWave(standardAudioData1);
	 	   System.out.println("��ʾ��ʱ��������");
//	 	   3. ��ȡ��Ƶ�ź���Ч����
	 	   standardUsefulData = showUsefulWave(standardEnergyData) ;
	 	   return standardUsefulData;
	    }
	    
}
