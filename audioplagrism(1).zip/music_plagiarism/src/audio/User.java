package audio;

import java.util.Scanner;

public class User {
	public String name=null;
	private String key=null;
	public static Data undolist[]=new Data[2];
//	public static User userlist[]=new User[10];
	public User(String name,String key){
		this.name=name;
		this.key=key;
	}
	static void usercreate(User user)
	{
//		String name=null;
//		String key=null;
		
		System.out.println("������ע���û�����");
		Scanner sc = new Scanner(System.in);
		user.name = sc.nextLine(); 
		System.out.println("������ע�����룺");
		user.key = sc.nextLine(); 
	
	
	}
//	static void userlogin(String name,String key) {
//		if(user.key==key)
//			{System.out.println("��¼�ɹ�");}
//		else {System.out.println("�û��������벻����");};
//	}
	
//	static void userupload
	static void add_undo(Data data,int i) {
		undolist[i]=data;
	}
}
