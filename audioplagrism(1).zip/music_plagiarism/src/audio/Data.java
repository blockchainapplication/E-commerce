package audio;

public class Data {
	int ID;
	String audiofingerprint;
	String name;
	String minername;
	public String hash_set;
	private static int sequence = 0;

	public Data(int ID, String codefingerprint, String name,String minername) {
		this.ID = ID;
		this.audiofingerprint = codefingerprint;
		this.name = name;
		this.minername=minername;

	}

	private String calulateHash() {
		sequence++;
		return StringUtil.applySha256(Integer.toString(ID) + name + audiofingerprint + sequence);
	}
}
