#基于区块链的商品信息溯源系统<br>
#首先下载完整的E-commerce-blockchain于本地并复制路径所在位置<br><br><br>
#打开eclipse，import下载好的project<br><br>
#1）： 点击 file<br>
#2）：点击 import<br>
#3）：点击  existing  projects into workspace<br>
#4）：粘贴复制的路径在 select root dictionary<br>
#5）：然后点下方的import。<br>
#成功import项目后会在project explorer里出现一个文件夹，名字为E-commerce-blockchain<br>
#6）展开E-commerce-blockchain<br>
#7）展开src<br>
#8）展开commercechain<br>
#9）双击noobchain.java。该类里包含了主函数，即运行代码的入口。运行该代码即可。<br>
#代码运行第一行：正在爬取京东信息......<br>
