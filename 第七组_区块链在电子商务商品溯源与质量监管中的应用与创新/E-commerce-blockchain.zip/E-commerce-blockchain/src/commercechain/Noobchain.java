package commercechain;

//https://search.jd.com/Search?keyword=%E4%BD%99%E5%8D%8E&enc=utf-8&wq=%E4%BD%99%E5%8D%8E&pvid=447c16e08d2340f8b185bdca0eefe345
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.*;

public class Noobchain {
	public static ArrayList<Block> blockchain = new ArrayList();
	public static ArrayList<Block> blockchain_1 = new ArrayList();
	public static ArrayList<Block> blockchain_2 = new ArrayList();
	public static ArrayList<Block> blockchain_3 = new ArrayList();

	public static ElectricityContract electricityContract = new ElectricityContract();
	// 挖矿难度
	public static int difficulty = 1;
	public static Gson gson = new Gson();

	public static void main(String[] args) {
		List<Goods> goods = produceGoodsService();// 商品生产
		qualityInspectionService(goods);// 质量检测
		electricityContract.setGoods(goods);
		List<Consumers> consumers = userService();	// 创建用户
		electricityContract.setConsumers(consumers);
		salesService(electricityContract);// 销售
		storageBlock();		// 发布电商智能合约

	}

	static List<Goods> produceGoodsService() {

		ArrayList<Goods> goodsList = new ArrayList();

		try {
			System.out.println("正在爬取京东商品信息......");
			CloseableHttpClient httpClient = HttpClientBuilder.create().build();

			HttpGet httpGet = new HttpGet(
					"https://search.jd.com/Search?keyword=%E6%B8%B8%E6%88%8F%E6%9C%AC&enc=utf-8&wq/"
					+ "=%E6%B8%B8%E6%88%8F%E6%9C%AC&pvid=2c0f32eefb4f4430898af463e0ef4490"); 

			httpGet.setHeader("User-Agent",
					"Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:50.0) Gecko/20100101 Firefox/50.0"); 
																										
			CloseableHttpResponse response = httpClient.execute(httpGet);

			String result = EntityUtils.toString(response.getEntity(), "utf-8");

			Document document = Jsoup.parse(result);
			Elements elementsByClass = document.getElementsByClass("gl-i-wrap");
			for (int i = 0; i < 5; i++) {
				Element element = elementsByClass.get(i);
				Elements shopStr = element.getElementsByClass("p-shop");
				Element element2 = shopStr.get(0);
				Elements elementsByClass2 = element.getElementsByClass("curr-shop");
				String brand = elementsByClass2.text();
				Elements shopnum = element.getElementsByClass("p-shopnum");
				Elements name = element.getElementsByClass("p-name");
				Elements price = element.getElementsByClass("p-price");
				//
				String priceStr = price.text();
				String quality = priceStr.substring(1, priceStr.length());
				String shopnumStr = shopnum.text();
				String nameStr = name.text();
				System.out.println("商品名称：	" + nameStr + "    生产商（品牌/制造商）：	" + brand + "      出售价格：	" + quality);
				Goods goods = new Goods(nameStr, brand, nameStr, (int) (Math.random() * 100), Double.valueOf(quality),
						999);
				goodsList.add(goods);
			}
		} catch (Exception e) {
			System.out.println("获取失败");

		}
		return goodsList;
	}

	static void qualityInspectionService(List<Goods> goodsList) {

		System.out.println("质量检测中");
		Iterator<Goods> it = goodsList.iterator();
		while (it.hasNext()) {
			Goods goods = it.next();
			int quality = 60;
			if (goods.getQuality() < quality) {
				it.remove();
				System.out
						.println("商品:" + goods.getSerialNumber() + "      质检发现该商品质量低于" + 
				quality + "  鉴定为不合格,不给予上架并删除");
			}
		}
	}

	static void salesService(ElectricityContract electricityContract) {
		System.out.println("商品销售中");
		List<Consumers> consumers = electricityContract.getConsumers();
		List<Goods> goods = electricityContract.getGoods();
		for (int c = 0; c < consumers.size(); c++) {
			if (c < goods.size()) {
				Consumers consumer = consumers.get(c);
				Goods s = goods.get(c);
				double balance = consumer.getBalance();
				double price = s.getPrice();
				if (balance > price) {
					double newBalance = balance - price; // balance = balance -price
					consumer.setBalance(newBalance);
					System.out.println("消费者:    " + consumer.getNickname() + "付款:" + price);
					System.out.println("消费者:    " + consumer.getNickname() + "账户余额:" + newBalance);
					int inventory = s.getInventory();
					inventory--;
					s.setInventory(inventory);
					System.out.println("商品:    " + s.getName() + "库存减一 ,剩余:" + inventory);
					System.out.println("消费者:    " + consumer.getNickname() + "购买了:" + s.toString());
					Order order = new Order(UUID.randomUUID().toString(), price, consumer.getUid(),
							Logistics.SEND_GOODS, false, Arrays.asList(s));
					System.out.println("生成订单:   " + order.toString());
					System.out.println("商品:   " + s.getName() + "正准备出仓");
					logistics(order);
					evaluationService(consumer, s);
					electricityContract.setOrders(Arrays.asList(order));
				}
			}
		}
	}

	static void logistics(Order order) {
		try {
			Thread.sleep(1000);
			System.out.println("商品:   " + order.getGoods().get(0).getName() + "    发货");
			Thread.sleep(1000);
			System.out.println("商品:   " + order.getGoods().get(0).getName() + "    运输中");
			Thread.sleep(1000);
			System.out.println("商品:   " + order.getGoods().get(0).getName() + "    派件中");
			Thread.sleep(1000);
			System.out.println("商品:   " + order.getGoods().get(0).getName() + "    签收");
			order.setLogistic(Logistics.SIGN_FOR);
			order.setState(true);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	static void evaluationService(Consumers consumer, Goods s) {
		Evaluation evaluation = new Evaluation(consumer.getNickname(), (int) (Math.random() * 5), new Date());
		s.setEvaluation(Arrays.asList(evaluation));
		System.out.println(
				"消费者:    " + consumer.getNickname() + "评级了:" + s.getName() + "评分:" + evaluation.getEvaluationScore());
	}

	static List<Consumers> userService() {
		Consumers consumer1 = new Consumers("CaryonVLelouch", 9999D, "上海市嘉定区城中路20号上海大学", UUID.randomUUID().toString());
		Consumers consumer2 = new Consumers("Thor", 9999D, "上海市嘉定区城中路20号上海大学", UUID.randomUUID().toString());
		Consumers consumer3 = new Consumers("Lan", 9999D, "上海市嘉定区城中路20号上海大学", UUID.randomUUID().toString());

		return Arrays.asList(consumer1, consumer2, consumer3);
	}

	static void storageBlock() {
		System.out.println("商品数据&用户数据存储到区块链中");
		String s = gson.toJson(electricityContract);
		for (int a = 0; a < 2; a++) {
			blockchain.add(new Block(s, a + "")); // 创建区块
			System.out.println("Trying to Mine block " + a + "......");
			blockchain.get(a).mineBlock(difficulty);//
		}

		Thread t1 = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				// 节点 1
				int count1 = 0;
				while (count1 < blockchain.size()) {
					Block block = blockchain.get(count1);
					if (block == null) {
						blockchain_1.add(count1, block);
						
					}
					count1++;
					System.out.println(Thread.currentThread().getName() + "区块数据同步中。。。。。。");
				}
			}
		});
		t1.start();

		Thread t2 = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub

				// 节点 2
				int count22 = 0;
				while (count22 < blockchain.size()) {
					Block block = blockchain.get(count22);
					if (block == null) {
						blockchain_1.add(count22, block);
						
					}
					count22++;
					System.out.println(Thread.currentThread().getName() + "区块数据同步中。。。。。。");
				}
			}
		});
		t2.start();

		Thread t3 = new Thread(new Runnable() {

			@Override
			public void run() {
				// 节点 3
				int count3 = 0;
				while (count3 < blockchain.size()) {
					Block block = blockchain.get(count3);
					if (block == null) {
						blockchain_1.add(count3, block);
						
					}
					count3++;
					System.out.println(Thread.currentThread().getName() + "区块数据同步中。。。。。。");
				}
			}
		});

		t3.start();

		String blockchainJson = new GsonBuilder().setPrettyPrinting().create().toJson(blockchain);
		System.out.println("\nThe block chain: ");
		System.out.println(blockchainJson);

	}
	


	// 遍历链中的所有块并比较哈希值
	public static Boolean isChainValid() {
		String hashTarget = new String(new char[difficulty]).replace('\000', '0');
		for (int i = 1; i < blockchain.size(); i++) {
			Block currentBlock = (Block) blockchain.get(i);
			Block preciousBlock = (Block) blockchain.get(i - 1);
			if (!currentBlock.hash.equals(currentBlock.calculateHash())) {
				System.out.println("Current Hashes not equal");
				return Boolean.valueOf(false);
			}
			if (!preciousBlock.hash.equals(currentBlock.previousHash)) {
				System.out.println("Previous Hashes not equal");
				return Boolean.valueOf(false);
			}
			if (!currentBlock.hash.substring(0, difficulty).equals(hashTarget)) {
				System.out.println("This block hasn't been mined");
				return Boolean.valueOf(false);
			}
		}
		return Boolean.valueOf(true);
	}
}
