package commercechain;

public class Consumers {
	//用户id ，唯一表示
    private String  uid;
    private String  nickname ;
    	//账户余额 默认 1000D 块
    private double balance = 1000D;
    //收货地址
    private String shippingAddress;
    //订单对象
    private  Order order ;

    public Consumers(String nickname, double balance, String shippingAddress,String  uid) {
        this.nickname = nickname;
        this.balance = balance;
        this.shippingAddress = shippingAddress;
        this.uid = uid;
    }//构造函数

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(String shippingAddress) {
        this.shippingAddress = shippingAddress;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }
}
