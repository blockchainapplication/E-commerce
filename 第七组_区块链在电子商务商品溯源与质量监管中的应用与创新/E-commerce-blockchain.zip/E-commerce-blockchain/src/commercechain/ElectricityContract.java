package commercechain;

import java.util.ArrayList;
import java.util.List;
//电商商务合约 （智能合约）
public class ElectricityContract {
//商品列表集合
    private List<Goods> goods = new ArrayList<>();
    //消费者集合
    private List<Consumers>consumers = new ArrayList<>();
    //订单集合
    private List<Order>orders = new ArrayList<>();

    public ElectricityContract() {

    }
    public ElectricityContract(ArrayList<Goods> goods, ArrayList<Consumers> consumers, ArrayList<Order> orders) {
        this.goods = goods;
        this.consumers = consumers;
        this.orders = orders;
    }

    public List<Goods> getGoods() {
        return goods;
    }

    public void setGoods(List<Goods> goods) {
        this.goods = goods;
    }

    public List<Consumers> getConsumers() {
        return consumers;
    }

    public void setConsumers(List<Consumers> consumers) {
        this.consumers = consumers;
    }

    public List<Order> getOrders() {
        return orders;
    }

    public void setOrders(List<Order> orders) {
        this.orders = orders;
    }
}
