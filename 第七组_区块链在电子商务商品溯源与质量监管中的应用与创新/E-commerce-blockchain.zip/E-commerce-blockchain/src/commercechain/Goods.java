package commercechain;

import java.util.Date;
import java.util.List;
import java.util.UUID;

public class Goods {
    private String name;//商品名称
    private String manufacturers;// 制造商 生产者 
    private String serialNumber =UUID.randomUUID().toString();//编号
    private String brand;//品牌 一般制造商也做自己的品牌
    private int inventory;
    private int  quality ; // 数值越大,质量越高
    private double price ; //零售价
    private List<Evaluation> evaluation; //评分对象
    private Date productionTime  =  new Date(); //商品生产时间
    private Date lastUpdateTime =  new Date(); ;//最后修改时间

    public Goods(String name, String manufacturers, String brand, int quality, double price ,int inventory) {
        this.name = name;
        this.manufacturers = manufacturers;
        this.brand = brand;
        this.quality = quality;
        this.price = price;
        this. inventory = inventory ;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getManufacturers() {
        return manufacturers;
    }

    public void setManufacturers(String manufacturers) {
        this.manufacturers = manufacturers;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getQuality() {
        return quality;
    }

    public void setQuality(int quality) {
        this.quality = quality;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    public Date getProductionTime() {
        return productionTime;
    }

    public void setProductionTime(Date productionTime) {
        this.productionTime = productionTime;
    }

    public Date getLastUpdateTime() {
        return lastUpdateTime;
    }

    public void setLastUpdateTime(Date lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }


    public int getInventory() {
        return inventory;
    }

    public void setInventory(int inventory) {
        this.inventory = inventory;
    }

    @Override
    public String toString() {
        return "Goods{" +
                "name='" + name + '\'' +
                ", manufacturers='" + manufacturers + '\'' +
                ", brand='" + brand + '\'' +
                ", quality=" + quality +
                ", price=" + price +
                '}';
    }

    public List<Evaluation> getEvaluation() {
        return evaluation;
    }

    public void setEvaluation(List<Evaluation> evaluation) {
        this.evaluation = evaluation;
    }
}
