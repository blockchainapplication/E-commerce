package commercechain;
// enum 枚举类 订单物流的状态
public enum  Logistics {
    SEND_GOODS, //发货
    TRANSPORTING ,//运输中
    DELIVERYING,//派件中
    SIGN_FOR,//签收


}
