package commercechain;

import java.util.Date;
import java.util.List;
import java.util.UUID;

public class Order {
    private String serialNumber ;//订单编号
    private double totalPrice; //订单金额
    private String uid; //用户id  等于 Consumers的 uid 
    private Logistics logistic ; //当前订单的物流状态
    private boolean state ;//状态 true 完成  false 进行中
    private List<Goods> goods ; //商品对象集合
    private Date creatTime; //订单创建时间
    private Date payTime; //支付时间
    private Date sendGoodsTime; //发货时间

    //函数名和类名相同，且无返回值 的函数叫做构造函数 。 一样
    public Order(String serialNumber, double totalPrice, String uid, Logistics logistic, boolean state, List<Goods> goods) {
        this.serialNumber = serialNumber;
        this.totalPrice = totalPrice;
        this.uid = uid;
        this.logistic = logistic;
        this.state = state;
        this.goods = goods;
    }

    public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public Logistics getLogistic() {
		return logistic;
	}

	public void setLogistic(Logistics logistic) {
		this.logistic = logistic;
	}

	public boolean isState() {
		return state;
	}

	public void setState(boolean state) {
		this.state = state;
	}

	public List<Goods> getGoods() {
		return goods;
	}

	public void setGoods(List<Goods> goods) {
		this.goods = goods;
	}

	public Date getCreatTime() {
		return creatTime;
	}

	public void setCreatTime(Date creatTime) {
		this.creatTime = creatTime;
	}

	public Date getPayTime() {
		return payTime;
	}

	public void setPayTime(Date payTime) {
		this.payTime = payTime;
	}

	public Date getSendGoodsTime() {
		return sendGoodsTime;
	}

	public void setSendGoodsTime(Date sendGoodsTime) {
		this.sendGoodsTime = sendGoodsTime;
	}

    public String toString() {
        return "Order{" +
                "serialNumber='" + serialNumber + '\'' +
                ", totalPrice=" + totalPrice +
                ", uid='" + uid + '\'' +
                ", logistic=" + logistic +
                ", state=" + state +
                ", goods=" + goods +
                '}';
    }
}
