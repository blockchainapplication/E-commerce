package commercechain;

import java.util.Date;

public class Evaluation {
    private String   evaluatorsName; //评分者 （商品的购买者）
    private int evaluationScore; // 1--5分
    private Date evaluationTime ; //评论时间

    public Evaluation(String evaluatorsName, int evaluationScore, Date evaluationTime) {
        this.evaluatorsName = evaluatorsName;
        this.evaluationScore = evaluationScore;
        this.evaluationTime = evaluationTime;
    }

    public String getEvaluatorsName() {
        return evaluatorsName;
    }

    public void setEvaluatorsName(String evaluatorsName) {
        this.evaluatorsName = evaluatorsName;
    }

    public int getEvaluationScore() {
        return evaluationScore;
    }

    public void setEvaluationScore(int evaluationScore) {
        this.evaluationScore = evaluationScore;
    }

    public Date getEvaluationTime() {
        return evaluationTime;
    }

    public void setEvaluationTime(Date evaluationTime) {
        this.evaluationTime = evaluationTime;
    }
}
